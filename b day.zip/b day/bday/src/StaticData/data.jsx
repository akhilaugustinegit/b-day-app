export const data = [{
    id:1,
    name:'tomy',
    age:24,
    image:'https://images.generated.photos/lRe9puT964VFxEOadOc4O_wVUziZAUWMJdE58T-yYfo/rs:fit:256:256/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy92M18w/NzcwNDk1LmpwZw.jpg'
},

{
    id:2,
    name:'edward',
    age:42,
    image:'https://images.generated.photos/iszLfI8aAR9wlu6hmikBIbdfZhUbkidF4rcboNCpAoM/rs:fit:256:256/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy8wOTIz/MTk5LmpwZw.jpg'
},
{
    id:3,
    name:'eliz',
    age:23,
    image:'https://images.generated.photos/dD7ov6ih86AB6sGH5aLHGAZTpIdX5QKrUe9dxw1RUcU/rs:fit:512:512/wm:0.95:sowe:18:18:0.33/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy8wNTA3/ODk1LmpwZw.jpg'
},
{
    id:4,
    name:'samuel',
    age:30,
    image:'https://images.generated.photos/uhVTvSxGIA0t088JXSPta5ZK8efPDGcgV99bKcHZSiA/rs:fit:512:512/wm:0.95:sowe:18:18:0.33/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy8wNTMy/MTUzLmpwZw.jpg'
},
{
    id:5,
    name:'lily',
    age:34,
    image:'https://images.generated.photos/JdZLn5WyLaliYSe4n487P6Fkjyb9cR84nJCOt-E9580/rs:fit:512:512/wm:0.95:sowe:18:18:0.33/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy92M18w/ODczNjExLmpwZw.jpg'
}


]