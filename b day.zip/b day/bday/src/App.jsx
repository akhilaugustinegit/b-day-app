import React from 'react'
import Home from './componenets/Home/Home'

function App() {
  return (
    <><Home></Home></>
  )
}

export default App